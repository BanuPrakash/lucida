Routing Module, Lazy loading

1) Secure our routes
2) RESTful Web services has to stateless
Can't use Cookies for session tracking
Converstational state of client

Stateless ==> Token based authorization instead of Cookie
JWT ==> Json Web Token

eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c

Header:
{
  "alg": "HS256",
  "typ": "JWT"
}

Payload:
{
  "sub": "Banu",
  "iat": 1516239022,
  "exp" : 151699999,
  "roles": ["ROLE_ADMIN", "ROLE_MANAGER"],
  "issuer": "https://auth.lucida.com/auth"
}

Signature:
HMACSHA256(
  base64UrlEncode(header) + "." +
  base64UrlEncode(payload),
  mytopsecretslatvalue1234
) 

Symetric Key:"mytopsecretslatvalue1234"

Asymetric Key: Public key to generate Token
Private key to verify token


Login ==> token is generated and sent to client
Client --> store in window.sessionStorage
StorageService ==> store data, getUser(), getRoles() from token
"@auth0/angular-jwt"
 "jwt-decode": "^3.1.2",


{
    path:'customers',
    component:CustomerListComponent,
    canActivate: [AuthGuard] 
  },
  {
    path:'products',
    canActivate: [RoleGuard], 
    data: { 
      expectedRole: ['ROLE_ADMIN']
    } ,
    loadChildren:() => import('./product/product.module').then(m => m.ProductModule)
  }

  