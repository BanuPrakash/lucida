const express = require("express");
const cors = require("cors");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");

const app = express();

app.use(cors()); // Cross Origin request

// parse requests of content-type - application/json
app.use(express.json());

// parse requests of content-type - application/x-www-form-urlencoded
app.use(express.urlencoded({ extended: true }));

// simple route
app.get("/", (req, res) => {
  res.json({ message: "Welcome to  application." });
});

app.post("/login", (req, res) => {
    return sigin(req,res);
});

app.get("/products", (req, res) => {
  return [];
});
// set port, listen for requests
const PORT = process.env.PORT || 8080;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}.`);
});

 sigin = async (req, res) => {
 try {
    username = req.body.username;
    // secret
    password = "$2a$12$/Z29Nxf/aplAtZTX3FOzWO4PtlXAdi3rZUbwfocaUuhNSugUnxLbO";
    const passwordIsValid = bcrypt.compareSync(
      req.body.password,
      password
    );
    if (!passwordIsValid) {
      return res.status(401).send({
        message: "Invalid Username/Password!",
      });
    }
    

    let authorities = ["ROLE_MANAGER", "ROLE_GUEST"];
    const token = jwt.sign({ sub: username, roles: authorities }, 
        "MyTopSecret123SaltValue", {
      expiresIn: 86400, // 24 hours
    });
   

    return res.status(200).send({
      token
    });

  } catch (error) {
    return res.status(500).send({ message: error.message });
  }
};
