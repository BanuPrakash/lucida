import { NgModule } from '@angular/core';
import { Route, RouterModule, Routes } from '@angular/router';
import { CustomerListComponent } from './customers/customer-list/customer-list.component';
import { LoginComponent } from './login/login.component';
import { AuthGuard } from './common/auth.guard';
import { RoleGuard } from './common/role.guard';
import { HomeComponent } from './home/home.component';


const routes:Route[] = [
  {
    path:'login',
    component:LoginComponent
  },
  {
    path:'',
    component:HomeComponent
  },
  {
    path:'customers',
    component:CustomerListComponent,
    canActivate: [AuthGuard] 
  },
  {
    path:'products',
    canActivate: [RoleGuard], 
    data: { 
      expectedRole: ['ROLE_ADMIN']
    } , 
    loadChildren:() => import('./product/product.module').then(m => m.ProductModule)
  },
  {
    path:'**',
    component:CustomerListComponent
  }
]

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
