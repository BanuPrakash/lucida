import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { JwtHelperService } from '@auth0/angular-jwt';
import { Observable } from 'rxjs';
import { StorageService } from './storage.service';

const AUTH_API = 'http://localhost:8080/login/';

const jwtHelper = new JwtHelperService();
const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' }),
  accept: new HttpHeaders({ 'Accept': 'application/json' })
};

@Injectable(
  {
    providedIn:"root"
  }
)
export class AuthService {
  constructor(private http: HttpClient, private storageService:StorageService) {}

  login(username: string, password: string): Observable<any> {
    return this.http.post(
      AUTH_API ,
      {
        username,
        password,
      },
      httpOptions
    );
  }

  public isAuthenticated(): boolean {
    const token = this.storageService.getToken();
    return !jwtHelper.isTokenExpired(token);
  }
}