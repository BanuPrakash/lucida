import { Component, OnInit } from '@angular/core';
import Customer from '../customer';
import { faContactCard, faTableList } from '@fortawesome/free-solid-svg-icons';  
import { Observable, Subscription, shareReplay } from 'rxjs';
import { CustomerService } from 'src/app/shared/customer.service';

@Component({
  selector: 'app-customer-list',
  templateUrl: './customer-list.component.html',
  styleUrls: ['./customer-list.component.css'],
  providers: [CustomerService]
})
export class CustomerListComponent implements OnInit{
  faContactCard = faContactCard;
  faTableList = faTableList;
  "customers": Customer[] = []; // state
  customerObservable!: Observable<Customer[]>; 
  customerSubscription!:Subscription;
  
  constructor(private customerService:CustomerService) { 
    this.customerObservable = this.customerService.getCustomers().pipe(shareReplay());
  }
  ngOnDestroy(): void {
    this.customerSubscription.unsubscribe();// if not done ==> memory leaks
  }

  ngOnInit(): void {
    this.customerSubscription = this.customerObservable.subscribe(data => {
      this.customers =  data;
    });
    // no http call for second subscription because of shareReplay();
    this.customerObservable.subscribe(data => {
      console.log(data);
    });
  }

  deleteCustomer(id:number) {
    this.customerService.deleteCustomer(id).subscribe(data => console.log("Delete" , data));
    this.customerService.getCustomers().subscribe(data => {
      this.customers  = data;
    });
  }
}
