import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerListComponent } from './customer-list.component';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CustomerCardComponent } from '../customer-card/customer-card.component';
import Customer from '../customer';

describe('CustomerListComponent', () => {
  let component: CustomerListComponent;
  let fixture: ComponentFixture<CustomerListComponent>;
  let customers:Customer[] = [];
  beforeEach(async () => {
    customers = [{
      "id": 10,
      "firstName": "Rachel",
      "lastName": "Green ",
      "gender": "male",
      "address" : "some address"
    },
    {
      "id": 20,
      "firstName": "Chandler",
      "lastName": "Bing",
      "gender": "male",
      "address" : "some address"
    },
    {
      "id": 30,
      "firstName": "Joey",
      "lastName": "Tribbiani",
      "gender": "male",
      "address" : "some address"
    }]
    await TestBed.configureTestingModule({
      declarations: [ CustomerListComponent, CustomerCardComponent ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CustomerListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create 3 cards', () => {
    component.customers = customers;
    fixture.detectChanges();
    let cards = fixture.nativeElement.querySelectorAll(".card");
    expect(cards.length).toEqual(3);
  });

  it("should delete a customer", () => {
    component.customers = customers;
    component.deleteCustomer(20);
    fixture.detectChanges();
    let cards = fixture.nativeElement.querySelectorAll(".card");
    expect(cards.length).toEqual(2);

  });
});
