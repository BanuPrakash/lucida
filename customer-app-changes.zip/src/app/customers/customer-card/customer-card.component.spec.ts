import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerCardComponent } from './customer-card.component';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import Customer from '../customer';

describe('CustomerCardComponent', () => {
  let component: CustomerCardComponent;
  let fixture: ComponentFixture<CustomerCardComponent>;

  beforeEach(async () => {
   
    await TestBed.configureTestingModule({
      declarations: [ CustomerCardComponent ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CustomerCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should render a Card', () => {
    component.customers =  [{
      "id": 10,
      "firstName": "Rachel",
      "lastName": "Green ",
      "gender": "male",
      "address" : "some address"
    },
    {
      "id": 20,
      "firstName": "Chandler",
      "lastName": "Bing",
      "gender": "male",
      "address" : "some address"
    },
    {
      "id": 30,
      "firstName": "Joey",
      "lastName": "Tribbiani",
      "gender": "male",
      "address" : "some address"
    }];
    fixture.detectChanges();
    let cards = fixture.nativeElement.querySelectorAll(".card");
    expect(cards.length).toEqual(3);
  });

  it("tesing event @Output", () => {
    component.customers =  [{
      "id": 10,
      "firstName": "Rachel",
      "lastName": "Green ",
      "gender": "male",
      "address" : "some address"
    },
    {
      "id": 20,
      "firstName": "Chandler",
      "lastName": "Bing",
      "gender": "male",
      "address" : "some address"
    },
    {
      "id": 30,
      "firstName": "Joey",
      "lastName": "Tribbiani",
      "gender": "male",
      "address" : "some address"
    }];
    fixture.detectChanges();
    const deleteCustomer = spyOn(component.delEvent, 'emit');
    let deleteBtn = fixture.nativeElement.querySelectorAll("fa-icon");
    deleteBtn[0].click();
    expect(deleteCustomer).toHaveBeenCalled();
    expect(deleteCustomer).toHaveBeenCalledWith(10);
  });

});
