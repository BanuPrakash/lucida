import { Component, OnInit } from '@angular/core';
import Customer from '../customer';
import { faContactCard, faTableList } from '@fortawesome/free-solid-svg-icons';  

@Component({
  selector: 'app-customer-list',
  templateUrl: './customer-list.component.html',
  styleUrls: ['./customer-list.component.css']
})
export class CustomerListComponent implements OnInit{
  faContactCard = faContactCard;
  faTableList = faTableList;
  "customers": Customer[] = []; // state
  ngOnInit(): void {
    this.customers = [{
      "id": 1,
      "firstName": "Rachel",
      "lastName": "Green ",
      "gender": "male",
      "address" : "some address"
    },
    {
      "id": 2,
      "firstName": "Chandler",
      "lastName": "Bing",
      "gender": "male",
      "address" : "some address"
    },
    {
      "id": 3,
      "firstName": "Joey",
      "lastName": "Tribbiani",
      "gender": "male",
      "address" : "some address"
    },
    {
      "id": 4,
      "firstName": "Monica",
      "lastName": "Geller",
      "gender": "female",
      "address" : "some address"
    },
    {
      "id": 5,
      "firstName": "Ross",
      "lastName": "Geller",
      "gender": "male",
      "address" : "some address"
    },
    {
      "id": 6,
      "firstName": "Phoebe",
      "lastName": "Buffay",
      "gender": "female",
      "address" : "some address"
    }];
  }

  deleteCustomer(id:number): void {
    // delete customer by id
    this.customers = this.customers.filter(c => c.id !== id);
  }
}
