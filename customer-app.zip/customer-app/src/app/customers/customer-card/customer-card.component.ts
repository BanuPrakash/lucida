import { Component, EventEmitter, Input, Output } from '@angular/core';
import Customer from '../customer';
import { faTrashCan, faEdit } from '@fortawesome/free-solid-svg-icons';

@Component({
  selector: 'app-customer-card',
  templateUrl: './customer-card.component.html',
  styleUrls: ['./customer-card.component.css']
})
export class CustomerCardComponent {
  faTrashCan = faTrashCan;
  faEdit = faEdit;
  @Input()
  customers:Customer[] = [];
  
  @Output()
  delEvent:EventEmitter<number> = new EventEmitter<number>();
  
  deleteCustomer(id:number): void {
    console.log("delete ", id);
    this.delEvent.emit(id);
  }
}
