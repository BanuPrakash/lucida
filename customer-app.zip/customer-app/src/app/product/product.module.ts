import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProductListComponent } from './product-list/product-list.component';
import { ProductCardComponent } from './product-card/product-card.component';

import { Route, RouterModule } from '@angular/router';
import { FilterByBrandPipe } from '../shared/filter-by-brand.pipe';
import { FormsModule } from '@angular/forms';
import { TooltipDirective } from '../shared/tooltip.directive';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';


const routes:Route[] = [
  {
    path:'', // http://localhost:4200/products
    component:ProductListComponent
  }
];

@NgModule({
  declarations: [
    ProductListComponent,
    ProductCardComponent,
    FilterByBrandPipe,
    TooltipDirective
  ],
  imports: [
    FormsModule,
    CommonModule,
    FontAwesomeModule,
    RouterModule.forChild(routes)
  ]
})
export class ProductModule { }
