import { Component, Input, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { Product } from '../Product';
import { ProductService } from '../../shared/product.service';
import { faHeart, faShoppingCart } from '@fortawesome/free-solid-svg-icons';

@Component({
  selector: 'app-product-card',
  templateUrl: './product-card.component.html',
  styleUrls: ['./product-card.component.css']
})
export class ProductCardComponent implements OnInit {
  faHeart = faHeart;
  faShoppingCart = faShoppingCart;

  @ViewChild("temp")
  template!:TemplateRef<any>;
  @Input()
  product:Partial<Product> = {};
  
  constructor(private productService:ProductService) { }
  ngOnInit(): void {
  }
  addToCart(id:number) {
    this.productService.addToCart(id);
  }
}
