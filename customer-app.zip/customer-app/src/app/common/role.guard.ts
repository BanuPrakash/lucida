import { Injectable } from '@angular/core';
import { AuthService } from './auth.service';
import { ActivatedRouteSnapshot, Router } from '@angular/router';
import decode from 'jwt-decode';
import { StorageService } from './storage.service';

@Injectable({
    providedIn: 'root'
})
export class RoleGuard {

    constructor(public auth: AuthService,
        public router: Router, private storageService: StorageService) { }

    canActivate(route: ActivatedRouteSnapshot): boolean {
        // this will be passed from the route config
        // on the data property
        if (this.auth.isAuthenticated()) {
            const expectedRole = route.data["expectedRole"];
            const roles = this.storageService.getRoles();
            //@ts-ignore
            const foundRole = expectedRole.some(role => roles.includes(role));
            if (foundRole) {
                return true;
            }
        }
        this.router.navigate(['login']);
        return false;
    }
}

