import { Injectable } from '@angular/core';
import { JwtHelperService } from '@auth0/angular-jwt';
const jwtHelper = new JwtHelperService();

@Injectable({
  providedIn: 'root'
})
export class StorageService {
  constructor() {}

  clean(): void {
    window.sessionStorage.clear();
  }

  public saveToken(token: string): void {
    window.sessionStorage.removeItem("token");
    window.sessionStorage.setItem("token", JSON.stringify(token));
  }

  public getToken(): string {
    const token = window.sessionStorage.getItem("token");
    if(token) {
        return token;
    }
    return "";
  }

  public getRoles() : any {
    const token = window.sessionStorage.getItem("token") as string;
    return jwtHelper.decodeToken(token)["roles"];
  }

  public getUser() : any {
    const token = window.sessionStorage.getItem("token") as string;
    return jwtHelper.decodeToken(token)["sub"];
  }
  public isLoggedIn(): boolean {
    const token = window.sessionStorage.getItem("token");
    if (token) {
      return true;
    }

    return false;
  }
}