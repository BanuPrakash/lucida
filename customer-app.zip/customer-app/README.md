1) ng new customer-app

2) npm i bootstrap
css framework
bootstrap css can be included in "angular.json" as
 "node_modules/bootstrap/dist/css/bootstrap.min.css"
 
or
in styles.css
as
@import url( "node_modules/bootstrap/dist/css/bootstrap.min.css")


3) ng add @fortawesome/angular-fontawesome

for icons

4) npm i karma-coverage-istanbul-reporter

for Code Coverage

5) ng config karma
customize karma config
karma.conf.js


ng g c customers/customer-list

ng g c customers/customer-card

6) copied images/ into assets folder



Testing 
descibe ==> Test suite
it --> test case


===========================

ChangeDetection Policy

====

Multiple module
1) shared module ==> common features required across all modules
2) user module ==> register, login
3) customer module
4) product module
5) order module

<script src="main.js"></script>

Advantage:
Lazy loading of modules can be done
Different routes can load different Modules
--> Core Web Vitals ==> FCP ==> First Contentful paint

http://amazon.com/mobiles ==> Mobile module is loader

http://amazon.com/cart ==> order module is loaded

customer was in root module ==> app.module.ts

Protecting modules by using Guards ==> Authorization

ng g module product

ng g component product/product-list --module=product

ng g component product/product-card --module=product

Routes in app.module ==> root
Routes in product.module ==> child routes

============

